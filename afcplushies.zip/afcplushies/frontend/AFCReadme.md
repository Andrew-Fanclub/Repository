# Scuffed but official readme for our AFCPlushies web scraper application

-------------------------------------------------------------------------------------
# Getting Started
-------------------------------------------------------------------------------------
This application is a web scraper that essentially scrapes the internet for plushies.
-------------------------------------------------------------------------------------
Our goal is to have a functioning website running on:
ReactJS - For frontend
SQL - For backend
Python - For scraping using BeautifulSoup
Heroku - For free webhosting
-------------------------------------------------------------------------------------
In order to run a development build of the application:
Run sudo yarn start in a CLI which should compile and run it in a localhost
-------------------------------------------------------------------------------------
In order to add any modules needed:
Run sudo yarn add 'name of module'
-------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------
# Features in the works/completed so far
-------------------------------------------------------------------------------------
In the works:
Mailer - Uses nodemailer for contacting our email through a text field and mailjet api
Navigation Bar - Self explanatory
-------------------------------------------------------------------------------------
Completed
Nothing yet lmao
-------------------------------------------------------------------------------------
# Authors: Mj, Yik, Catherine, Cheah, Matthew, Brad