import './public/main.css';
import Navigation from './components/navbar.js'

function Main(){
    return(
        <div>
            <head>
                <title>AFCPlushies</title>
                <link rel="icon" href="/favicon.ico"></link>
            </head>
            <div>
                <Navigation />
            </div>
            <p>
                AFCPlushies
            </p>
        </div>
    );
}

export default Main;