app.post('/process', function(req, res){
    const mailer = require('nodemailer');
    const smtp = require('nodemailer-smtp-transport');
    async function mailjet(){
        const transport = mailer.createTransport(
            smtp({
                host: 'in.mailjet.com',
                port: 2525,
                auth:{
                    user: process.env.MAILJET_API_KEY || '#insertapikeyhere',
                    pass: process.env.MAILJET_API_SECRET || '#insertpasskeyhere',
                },
            })
        );
        const json = await transport.sendMail({
            from: 'andrewfanclub@gmail.com',
            to: 'andrewfanclub@gmail.com',
            subject: req.body.email,
            text: req.body.ques,
        });
        console.log(json);
    }
    res.redirect(303, '/thankyou.html');
    mailjet();
});