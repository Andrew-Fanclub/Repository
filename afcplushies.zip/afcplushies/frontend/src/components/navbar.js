import '../public/nav.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Navbar, NavItem, NavDropdown, MenuItem, Nav, Form, FormControl, Button, Containeer, Header, pullRight} from 'react-bootstrap';
import React, { Component } from 'react';

function Navigation(){
    return(
        <div>
            <Navbar inverse collapseOnSelect>
                <Navbar.Header>
                    <Navbar.Brand>
                        <a>React-Bootstrap</a>
                    </Navbar.Brand>
                        <Navbar.Toggle />
                </Navbar.Header>
                <Navbar.Collapse>
                    <Nav>
                        <NavItem eventKey={1}>Link</NavItem>
                        <NavItem eventKey={2}>Link</NavItem>
                    </Nav>
                    <Nav pullRight>
                        <NavItem eventKey={1}>Link Right</NavItem>
                        <NavItem eventKey={2}>Link Right</NavItem>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>
        </div>
    );
}

export default Navigation;